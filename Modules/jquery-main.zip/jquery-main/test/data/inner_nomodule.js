QUnit.assert.ok( QUnit.isIE, "evaluated: inner nomodule script with src" );
